package checkbox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.BrowserHelper;

public class Singlecheckbox extends BrowserHelper {
	@Test
	public void checkboxlebel() {
		driver.get("https://www.qa-practice.com/elements/checkbox/single_checkbox");
		String lebel = driver.findElement(By.cssSelector(".form-check-label")).getText();
		Assert.assertEquals(lebel, "Select me or not");
	}

	@Test
	public void clickcheckbox() throws InterruptedException {
		//driver.get("https://www.qa-practice.com/elements/checkbox/single_checkbox");

		WebElement checkbox = driver.findElement(By.cssSelector("input#id_checkbox_0"));
		checkbox.click();

		Assert.assertEquals(checkbox.isSelected(), true);
		Thread.sleep(7000);
	}
	@Test
	public void clicksubmit() throws InterruptedException {
		//driver.get("https://www.qa-practice.com/elements/checkbox/single_checkbox");

		driver.findElement(By.cssSelector("#submit-id-submit")).click();
		String msg = driver.findElement(By.cssSelector("div#result > p:nth-of-type(1)")).getText();
		Thread.sleep(7000);
		Assert.assertEquals(msg, "Selected checkboxes:");
	}

}
