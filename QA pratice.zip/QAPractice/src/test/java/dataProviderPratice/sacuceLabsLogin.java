package dataProviderPratice;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utility.BrowserHelper;

public class sacuceLabsLogin extends BrowserHelper {
	
	@Test(dataProvider = "logindataneg")
	public void logintestNegative(String username, String password) throws InterruptedException {
		driver.get("https://www.saucedemo.com/");
		driver.findElement(By.cssSelector("input#user-name")).sendKeys(username);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input#password")).sendKeys(password);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input#login-button")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/");
		Thread.sleep(2000);
	}

// need assertion

	@DataProvider(name = "logindataneg")
	public Object[][] loginneg() {
		return new Object[][] { { "standard_user", "" },
								{ "", "secret_sauce" },
								{ "standard_userRaton",	"secret_sauce" },
						     	{ "telentech", "telentech" } };
	}

	@Test(dataProvider = "loginpos")
	public void logintestPositive(String username, String password) throws InterruptedException {
		driver.get("https://www.saucedemo.com/");
		driver.findElement(By.cssSelector("input#user-name")).sendKeys(username);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input#password")).sendKeys(password);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input#login-button")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
		Thread.sleep(2000);
	}

	// need assertion

	@DataProvider//(name = "logindatapos")//
	public Object[][] loginpos() {
		return new Object[][] { { "standard_user", "secret_sauce" }, 
								{ "visual_user", "secret_sauce" },
								{ "problem_user", "secret_sauce" }, 
								{ "performance_glitch_user", "secret_sauce" } };
				
	}
	
	@DataProvider
	public Object[][] getData(){
		Object[][] data = new Object[4][2];
		data[0][0] = "username1@gmail.com";
		data[0][1] = "password1";
		data[1][0] = "username2@gmail.com";
		data[1][1] = "password2";
		data[2][0] = "username3@gmail.com";
		data[2][1] = "password3";
		data[3][0] = "username4@gmail.com";
		data[3][1] = "password4";
		return data;
	}
}






