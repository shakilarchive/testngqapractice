package dataProviderPratice;

public class java2dArray {

	public static void main(String[] args) {
		String students[] = { "nahiyan", "david", "zia" };
		/*System.out.println(students[0]);
		System.out.println(students[1]);
		System.out.println(students[2]);*/
		
		String studentsAge [][]= { {"nahiyan","27"} ,
			                    	{"david","35"},
			                    	{"zia","22"} };
		System.out.println(studentsAge [2][0]); 
		System.out.println(studentsAge [1][0]); 
		studentsAge[1][0]="David";
		System.out.println(studentsAge [1][0]); 
		System.out.println("nahiyan old data "+ studentsAge [0][1] );
		studentsAge [0][1]="28";
		System.out.println("nahiyan new data "+ studentsAge [0][1] );
		
		
	/*	String sAge[][]= new String[3][2];
		System.out.println(sAge[2][1]);
		sAge[2][1]="22";
		System.out.println(sAge[2][1]);
		sAge[2][0]="zia";
		System.out.println(sAge[2][0]);*/
		
		
		
	}
}
