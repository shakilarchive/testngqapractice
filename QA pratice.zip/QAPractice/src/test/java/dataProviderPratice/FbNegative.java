package dataProviderPratice;

import org.testng.annotations.Test;

import utility.BrowserHelper;
	/*As a user, I would like to visit facebook.
	com an enter invalid email and pass and click on the login button. 
	I will not be able to log in.*/
public class FbNegative extends BrowserHelper{

	@Test
	public void fbNegative()
	{
	driver.get("https://www.facebook.com/");	
	}
	
	
}
