package input;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.BrowserHelper;

public class  InputPassword extends BrowserHelper{
	@Test
public void InputPasswordPositive() {
	driver.get("https://www.qa-practice.com/elements/input/passwd");
	String password = "Raton_123telentech@*";
	driver.findElement(By.cssSelector("input#id_password")).sendKeys(password);
	Actions actions = new Actions(driver);
	actions.sendKeys(Keys.ENTER).perform();
	String PasswordWebText = driver.findElement(By.xpath("/html//p[@id='result-text']")).getText();

	Assert.assertEquals(PasswordWebText, password);
}
}


