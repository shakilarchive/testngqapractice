package input;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.BrowserHelper;

public class InputsEmailInput extends BrowserHelper {
	
	
	
	@Test
	public void emailpositive() throws InterruptedException {
		driver.get("https://www.qa-practice.com/elements/input/email");
		String name = "raton@gmail.com";
		// write
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/form/div/input")).sendKeys(name);
		// hit enter
		Actions actions = new Actions(driver);
		actions.sendKeys(Keys.RETURN).perform(); // or ac
		// verify same name
		String name2 = driver.findElement(By.cssSelector("#result-text")).getText();
		Assert.assertEquals(name2, name);
		Thread.sleep(5000);
	}
	
	@Test
	public void emailnegative() throws InterruptedException {
		driver.get("https://www.qa-practice.com/elements/input/email");
		String name = "raton";
		// write
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/form/div/input")).sendKeys(name);
		// hit enter
		Actions actions = new Actions(driver);
		actions.sendKeys(Keys.RETURN).perform(); // or ac
		// verify same name
		String name2 = driver.findElement(By.cssSelector("strong")).getText();
		Assert.assertEquals(name2, "Enter a valid email address.");
		Thread.sleep(5000);
	}


}
