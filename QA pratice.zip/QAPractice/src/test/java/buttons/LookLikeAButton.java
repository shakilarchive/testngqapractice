package buttons;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.BrowserHelper;


public class LookLikeAButton extends BrowserHelper{
@Test
public void LookLikeAButton() {
	
	driver.get("https://www.qa-practice.com/elements/button/like_a_button");
	driver.findElement(By.linkText("Click")).click();
	String clickText = driver.findElement(By.xpath("/html//p[@id='result-text']")).getText();
	Assert.assertEquals(clickText, "Submitted");
	
}
}

