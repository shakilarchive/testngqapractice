package buttons;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.BrowserHelper;

public class simpleButton extends BrowserHelper{
@Test
public void simpleButton() {
	
	driver.get("https://www.qa-practice.com/elements/button/simple");
	driver.findElement(By.cssSelector("input#submit-id-submit")).click();
	String clickText = driver.findElement(By.xpath("/html//p[@id='result-text']")).getText();
	Assert.assertEquals(clickText, "Submitted");
	
}

@Test
public void ArrayList_forLoop() throws InterruptedException {
	ArrayList<String>urls = new ArrayList<String>();
	urls.add("https://www.prothomalo.com/");
	urls.add("https://www.jugantor.com/");
	urls.add("https://bdnews24.com/");
	
	for(int x = 0;x<urls.size();x++)
	{
		driver.get(urls.get(x));
		Thread.sleep(7000);
	}
	
	
	
	
	
	
	
	
	
}


}

