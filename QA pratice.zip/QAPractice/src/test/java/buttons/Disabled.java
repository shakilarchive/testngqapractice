package buttons;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.BrowserHelper;



public class Disabled extends BrowserHelper{
@Test(priority = 1)
	public void DisabledByDefault() {
		
		driver.get("https://www.qa-practice.com/elements/button/disabled");
		
		WebElement DropDownElement = driver.findElement(By.xpath("/html//select[@id='id_select_state']"));
		Select DropDownList = new Select(DropDownElement);
		 WebElement selectedOption = DropDownList.getFirstSelectedOption();
		String SelectoptionText = selectedOption.getText();
		Assert.assertEquals(SelectoptionText,"Disabled");
	}
@Test(priority = 2)
public void EnableAndDisabled() {
	
	
	WebElement DropDownElement = driver.findElement(By.xpath("/html//select[@id='id_select_state']"));
	Select DropDownList = new Select(DropDownElement);
	
	DropDownList.selectByVisibleText("Enabled");
	 WebElement selectedOption = DropDownList.getFirstSelectedOption();
	String SelectoptionText = selectedOption.getText();
	Assert.assertEquals(SelectoptionText,"Enabled");
	
	DropDownList.selectByVisibleText("Disabled");
	 selectedOption = DropDownList.getFirstSelectedOption();
	 SelectoptionText = selectedOption.getText();
	Assert.assertEquals(SelectoptionText,"Disabled");
	
	
	
}
@Test(priority= 3)
public void CilcikOnEnable() {
	
	
	WebElement DropDownElement = driver.findElement(By.xpath("/html//select[@id='id_select_state']"));
	Select DropDownList = new Select(DropDownElement);
	
	DropDownList.selectByVisibleText("Enabled");
	 WebElement selectedOption = DropDownList.getFirstSelectedOption();
	String SelectoptionText = selectedOption.getText();
	Assert.assertEquals(SelectoptionText,"Enabled");
	
	driver.findElement(By.cssSelector("#submit-id-submit")).click();
	
	String sub = driver.findElement(By.cssSelector("p#result-text")).getText();
	Assert.assertEquals(sub, "Submitted");
}

	}

/* Select shoeSizeDropDownlist = new Select(bgshoe.ShoeSizeDropDown);
		    shoeSizeDropDownlist.selectByVisibleText("8");

		    // Get the selected option's text
		    WebElement selectedOption = shoeSizeDropDownlist.getFirstSelectedOption();
		    String selectedSize =selectedOption.getText();
		   int selectedSizeint = Integer.valueOf(selectedSize);
		    
		    // Assert that the selected size matches the expected value
		    Assert.assertEquals(selectedSizeint, size);
		}*/
